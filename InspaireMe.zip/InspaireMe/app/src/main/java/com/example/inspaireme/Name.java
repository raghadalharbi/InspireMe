package com.example.inspaireme;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Name extends AppCompatActivity {


    EditText txtname ;
    Button btn;
    DatabaseReference reff ;
    com.example.inspaireme.Member member ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_name);
        txtname = findViewById(R.id.editText10);
        btn = findViewById(R.id.button10);
        member = new com.example.inspaireme.Member();
        reff = FirebaseDatabase.getInstance().getReference().child("Member");
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                member.setName(txtname.getText().toString().trim());
                reff.setValue(member);
                Toast.makeText(Name.this,"data inserted succesfuly " ,Toast.LENGTH_LONG).show();

            }
        });
    }
}
