package com.example.inspaireme;


public class Member {

    private String Name ;



    public Member() {


    }
    public String getName(){

        return this.Name;
    }

    public void setName(String name){
        this.Name = name ;

    }

}
