package com.example.inspaireme;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Main extends AppCompatActivity {
    Button SIGNOUT;
    TextView tv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        tv = (TextView)findViewById(R.id.textView);
        if (user != null) {
            String email = user.getEmail();
            tv.setText(email);
        }
        SIGNOUT = (Button) findViewById(R.id.signout5);
        SIGNOUT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                finish();
                startActivity(new Intent(getApplicationContext(), MainActivity.class));
            }
        });
    }


}
