package com.example.inspaireme;


public class Member {

    private String Name ;



    public Member() {


    }
    public String getName(){

        return Name;
    }

    public void setName(String name){
        Name = name ;

    }

}
