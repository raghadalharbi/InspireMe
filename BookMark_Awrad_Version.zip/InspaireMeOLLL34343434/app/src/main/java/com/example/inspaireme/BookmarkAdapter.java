package com.example.inspaireme;


import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class BookmarkAdapter extends BaseAdapter {

    private static ArrayList<Bookmark> bookmarks;
    public Context mContext;

    public BookmarkAdapter(Context context, ArrayList<Bookmark> comingBookmarks) {
        bookmarks = comingBookmarks;
        mContext = context;
    }

    public View getView(final int position, View convertView, ViewGroup parent) {


        LayoutInflater mInflater = (LayoutInflater) mContext.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
        convertView = mInflater.inflate(R.layout.list_item_bookmark, null);

        TextView tvTitle = convertView.findViewById(R.id.tv_post_title);

        ImageView ivPost = convertView.findViewById(R.id.iv_post_image);


        Glide.with(mContext).load(bookmarks.get(position).getImageUrl()).into(ivPost);

        tvTitle.setText(bookmarks.get(position).getPostTitle());

        return convertView;
    }

    //region other methods
    public int getCount() {
        return bookmarks.size();
    }

    public Object getItem(int position) {
        return bookmarks.get(position);
    }

    public long getItemId(int position) {
        return position;
    }
    //endregion

}