package com.example.inspireme;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import com.firebase.client.DataSnapshot;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;
import com.firebase.client.ValueEventListener;

public class MainActivity extends AppCompatActivity {




    private String textValue = "Awrad";
    private TextView mdisplayName;

    private Firebase mRef;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mdisplayName = (TextView) findViewById(R.id.displayName);

        mRef = new Firebase("https://inspireme-d384c.firebaseio.com/Name");

        mRef.addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                String value = dataSnapshot.getValue(String.class);

                mdisplayName.setText(value);

            }

            @Override
            public void onCancelled(FirebaseError firebaseError) {

            }
        });



    }
}
