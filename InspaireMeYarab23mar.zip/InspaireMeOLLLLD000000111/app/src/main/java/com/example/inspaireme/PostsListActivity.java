package com.example.inspaireme;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.Collections;

public class PostsListActivity extends AppCompatActivity {

    ListView listPosts;

    ArrayList<MyPost> posts = new ArrayList<>();

    String category = "";
    ImageView ivGoBack3;


    DatabaseReference bookmarkReference;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_posts_list);

        category = getIntent().getStringExtra("Category");

        listPosts = findViewById(R.id.list_posts);
        listPosts.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Intent i = new Intent(PostsListActivity.this, CommentsActivity.class);
                i.putExtra("POST_ID", posts.get(position).getId());
                i.putExtra("POST_TITLE", posts.get(position).getPostTitle());
                startActivity(i);

            }
        });

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference().child("Posts");
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                posts.clear();

                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {

                    MyPost myPost = snapshot.getValue(MyPost.class);
                    myPost.setId(snapshot.getKey());

                    if (category.trim().equals(myPost.getCategory()))
                        posts.add(myPost);
                }

                Collections.reverse(posts);

                PostsAdapter  postsAdapter = new PostsAdapter(PostsListActivity.this, posts);

                listPosts.setAdapter(postsAdapter);

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }

        });
        ivGoBack3 = findViewById(R.id.go_back3);
        ivGoBack3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(PostsListActivity.this, viewCategory.class);
                startActivity(i);

            }
        });
    }


    public void addPostToFavourites(int position) {

        Bookmark bookmark = new Bookmark();
        bookmark.setPostID(posts.get(position).getId());
        bookmark.setPostTitle(posts.get(position).getPostTitle());
        bookmark.setCategory(posts.get(position).getCategory());
        bookmark.setImageUrl(posts.get(position).getImageUrl());
        bookmark.setMemberName(posts.get(position).getMemberName());
        bookmark.setMemberPhoto(posts.get(position).getMemberPhoto());



        bookmarkReference = FirebaseDatabase.getInstance().getReference().child("Member").child(SessionClass.UID).child("Bookmarks").push();
        bookmarkReference.setValue(bookmark);
        Toast.makeText(getApplicationContext(), "Bookmark saved successfully", Toast.LENGTH_SHORT).show();

    }

}
