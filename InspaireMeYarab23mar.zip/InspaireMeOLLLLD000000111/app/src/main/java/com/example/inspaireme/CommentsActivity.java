package com.example.inspaireme;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class CommentsActivity extends AppCompatActivity {

    TextView tvPostCaption;

    EditText etComment;

    Button btnSendComment;

    ImageView ivGoBack4;



    String postId = "";
    String postTitle = "";

    DatabaseReference commentReference;

    ListView listComments;

    ArrayList<Comment> comments = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comments);

        postId = getIntent().getStringExtra("POST_ID");
        postTitle = getIntent().getStringExtra("POST_TITLE");

        tvPostCaption = findViewById(R.id.tv_post_caption);
        tvPostCaption.setText(postTitle);

        etComment = findViewById(R.id.et_comment);

        btnSendComment = findViewById(R.id.btn_send_comment);
        btnSendComment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //region validate
                if (etComment.getText().toString().trim().equals("")) {

                    Toast.makeText(CommentsActivity.this, "You must enter Comment", Toast.LENGTH_SHORT).show();

                    return;
                }

                //endregion


                Comment comment = new Comment();
                comment.setContent(etComment.getText().toString());
                comment.setMemberName(SessionClass.MemberName);
                comment.setTime(getCurrentTime());
                comment.setLikesNumber(0);
                etComment.setText("");


                commentReference = FirebaseDatabase.getInstance().getReference().child("Posts").child(postId).child("Comments").push();
                commentReference.setValue(comment);
                Toast.makeText(getApplicationContext(), "Comment sent successfully", Toast.LENGTH_SHORT).show();

            }
        });


        listComments = findViewById(R.id.list_comments);

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference().child("Posts").child(postId).child("Comments");
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                comments.clear();

                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {

                    Comment comment = snapshot.getValue(Comment.class);
                    comment.setId(snapshot.getKey());

                    if (comment.getTime() == null)
                        comment.setTime("");

                    comments.add(comment);


                }

                CommentsAdapter  commentsAdapter = new CommentsAdapter(CommentsActivity.this, comments);

                listComments.setAdapter(commentsAdapter);


            }


            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
        ivGoBack4 = findViewById(R.id.go_back4);
        ivGoBack4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(CommentsActivity.this, PostsListActivity.class);
                startActivity(i);

            }
        });
    }

    private String getCurrentTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        return sdf.format(new Date());
    }

    public void addLike(int position) {

        int currentLikes = comments.get(position).getLikesNumber();
        currentLikes ++;
        Comment comment = new Comment();
        comment.setContent(comments.get(position).getContent());
        comment.setMemberName(comments.get(position).getMemberName());
        comment.setTime(comments.get(position).getTime());
        comment.setLikesNumber(currentLikes);


        commentReference = FirebaseDatabase.getInstance().getReference().child("Posts").child(postId).child("Comments").child(comments.get(position).getId());
        commentReference.setValue(comment);
        Toast.makeText(getApplicationContext(), "Like added successfully", Toast.LENGTH_SHORT).show();

    }
}
