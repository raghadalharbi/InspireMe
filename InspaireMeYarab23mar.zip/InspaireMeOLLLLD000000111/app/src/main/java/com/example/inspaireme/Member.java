package com.example.inspaireme;


public class Member {

    private String Name ;
    private String Img;


    public Member() {


    }
    public String getName(){

        return this.Name;
    }

    public void setName(String name){
        this.Name = name ;

    }

    public void setImg(String img) {
        Img = img;
    }

    public String getImg() {
        return Img;
    }
}
