package com.example.inspaireme;

public class SessionClass {

    public static String MemberName = "";

    public static String UID = "";

}
