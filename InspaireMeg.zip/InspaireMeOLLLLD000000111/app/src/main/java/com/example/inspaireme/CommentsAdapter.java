package com.example.inspaireme;


import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;


import java.util.ArrayList;

public class CommentsAdapter extends BaseAdapter {

    private static ArrayList<Comment> comments;
    public Context mContext;

    public CommentsAdapter(Context context, ArrayList<Comment> comingComments) {
        comments = comingComments;
        mContext = context;
    }

    public View getView(int position, View convertView, ViewGroup parent) {


        LayoutInflater mInflater = (LayoutInflater) mContext.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
        convertView = mInflater.inflate(R.layout.list_item_comment, null);

        TextView tvMemberName = convertView.findViewById(R.id.tv_member_name);

        TextView tvCommentContent = convertView.findViewById(R.id.tv_comment_content);


        tvMemberName.setText(comments.get(position).getMemberName());
        tvCommentContent.setText(comments.get(position).getContent());

        return convertView;
    }

    //region other methods
    public int getCount() {
        return comments.size();
    }

    public Object getItem(int position) {
        return comments.get(position);
    }

    public long getItemId(int position) {
        return position;
    }
    //endregion

}