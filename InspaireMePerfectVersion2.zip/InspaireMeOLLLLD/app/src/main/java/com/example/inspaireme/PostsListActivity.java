package com.example.inspaireme;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class PostsListActivity extends AppCompatActivity {

    ListView listPosts;

    ArrayList<MyPost> posts = new ArrayList<>();

    int flag;

    String uId = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_posts_list);

        flag = getIntent().getIntExtra("Flag", 1);

        uId = getIntent().getStringExtra("UID");

        listPosts = findViewById(R.id.list_posts);
        listPosts.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Intent i = new Intent(PostsListActivity.this, CommentsActivity.class);
                i.putExtra("POST_ID", posts.get(position).getId());
                startActivity(i);

            }
        });

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference().child("Posts");
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                posts.clear();

                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {

                    MyPost myPost = snapshot.getValue(MyPost.class);
                    myPost.setId(snapshot.getKey());

                    if (flag == 2) {

                        if (uId.trim().equals(myPost.getMemberID()))
                            posts.add(myPost);

                    }else {
                        posts.add(myPost);
                    }
                }

                PostsAdapter  postsAdapter = new PostsAdapter(PostsListActivity.this, posts);

                listPosts.setAdapter(postsAdapter);

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }
}
