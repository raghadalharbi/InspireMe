package com.example.inspaireme;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

public class Main extends AppCompatActivity {

    //region views variables
    TextView tv;



    ImageView ivPostImg , ivDisplaypic, ivCategory, SIGNOUT, ivMyPosts;
   //endregion

    //region other variables
    String uId = "";
    //endregion

    StorageReference storage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        uId = getIntent().getStringExtra("UID");

        tv = (TextView) findViewById(R.id.textView);

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference().child("Member").child(uId);
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String name = dataSnapshot.child("name").getValue().toString();
                String imgUrl = dataSnapshot.child("img").getValue().toString();
                tv.setText(name);
                Glide.with(Main.this).load(imgUrl).into(ivDisplaypic);

                SessionClass.MemberName = name;
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        ivDisplaypic = findViewById(R.id.iv_displayPic);

        storage = FirebaseStorage.getInstance().getReference();

        SIGNOUT =  findViewById(R.id.signout);
        SIGNOUT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder alertDialog = new AlertDialog.Builder(Main.this);

                alertDialog.setMessage("Are you sure you want to logout?")

                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                                FirebaseAuth.getInstance().signOut();

                                Intent intent = new Intent(Main.this, Login.class);

                                startActivity(intent);

                                finish();

                            }
                        }).setNegativeButton("Cancel", null);

                AlertDialog alert = alertDialog.create();

                alert.show();

            }
        });




        ivPostImg = findViewById(R.id.iv_postImg);
        ivPostImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(Main.this, PostActivity.class);
                i.putExtra("UID", uId);
                startActivity(i);

            }
        });

        ivCategory = findViewById(R.id.iv_category);
        ivCategory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(Main.this, PostsListActivity.class);
                i.putExtra("Flag", 1);
                i.putExtra("UID", uId);
                startActivity(i);

            }
        });

        ivMyPosts = findViewById(R.id.iv_my_posts);
        ivMyPosts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(Main.this, PostsListActivity.class);
                i.putExtra("Flag", 2);
                i.putExtra("UID", uId);
                startActivity(i);

            }
        });
    }


}
