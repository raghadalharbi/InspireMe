package com.example.inspaireme;

public class MyPost {

    private String id;
    private String postTitle;
    private String category;
    private String imageUrl;
    private String memberID;
    private String memberName;
    private String memberPhoto;
    private String memberDeviceToken;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPostTitle() {
        return postTitle;
    }

    public void setPostTitle(String postTitle) {
        this.postTitle = postTitle;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getMemberID() {
        return memberID;
    }

    public void setMemberID(String memberID) {
        this.memberID = memberID;
    }

    public String getMemberName() {
        return memberName;
    }

    public void setMemberName(String memberName) {
        this.memberName = memberName;
    }

    public String getMemberPhoto() {
        return memberPhoto;
    }

    public void setMemberPhoto(String memberPhoto) {
        this.memberPhoto = memberPhoto;
    }

    public String getMemberDeviceToken() {
        return memberDeviceToken;
    }

    public void setMemberDeviceToken(String memberDeviceToken) {
        this.memberDeviceToken = memberDeviceToken;
    }
}
