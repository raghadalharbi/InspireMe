package com.example.inspaireme;

public class SessionClass {

    public static String MemberName = "";
    public static String MemberPhoto = "";
    public static String MemberDeviceToken = "";

    public static String UID = "";

}
