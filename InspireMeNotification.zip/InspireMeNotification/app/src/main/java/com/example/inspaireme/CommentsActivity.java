package com.example.inspaireme;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import javax.net.ssl.HttpsURLConnection;

public class CommentsActivity extends AppCompatActivity {

    TextView tvPostCaption;

    EditText etComment;

    Button btnSendComment;

    ImageView ivGoBack4;

    String myUID ;



    String postId = "";
    String postTitle = "";
    String postMemberDeviceToken = "";

    DatabaseReference commentReference;

    ListView listComments;

    ArrayList<Comment> comments = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comments);

        postId = getIntent().getStringExtra("POST_ID");
        postTitle = getIntent().getStringExtra("POST_TITLE");
        postMemberDeviceToken = getIntent().getStringExtra("DEVICE_TOKEN");

        tvPostCaption = findViewById(R.id.tv_post_caption);
        tvPostCaption.setText(postTitle);

        etComment = findViewById(R.id.et_comment);

        btnSendComment = findViewById(R.id.btn_send_comment);
        btnSendComment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //region validate
                if (etComment.getText().toString().trim().equals("")) {

                    Toast.makeText(CommentsActivity.this, "You must enter Comment", Toast.LENGTH_SHORT).show();

                    return;
                }

                //endregion


                Comment comment = new Comment();
                comment.setContent(etComment.getText().toString());
                comment.setMemberName(SessionClass.MemberName);
                comment.setTime(getCurrentTime());
                comment.setLikesNumber(0);
                etComment.setText("");


                commentReference = FirebaseDatabase.getInstance().getReference().child("Posts").child(postId).child("Comments").push();
                commentReference.setValue(comment);
                Toast.makeText(getApplicationContext(), "Comment sent successfully", Toast.LENGTH_SHORT).show();


                SendNotificationRequest sendNotificationRequest =new SendNotificationRequest();
                sendNotificationRequest.execute();

            }
        });


        listComments = findViewById(R.id.list_comments);

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference().child("Posts").child(postId).child("Comments");
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                comments.clear();

                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {

                    Comment comment = snapshot.getValue(Comment.class);
                    comment.setId(snapshot.getKey());

                    if (comment.getTime() == null)
                        comment.setTime("");

                    comments.add(comment);


                }

                CommentsAdapter  commentsAdapter = new CommentsAdapter(CommentsActivity.this, comments);

                listComments.setAdapter(commentsAdapter);


            }


            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
        ivGoBack4 = findViewById(R.id.go_back4);
        ivGoBack4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(CommentsActivity.this, PostsListActivity.class);
                startActivity(i);

            }
        });
    }

    private String getCurrentTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        return sdf.format(new Date());
    }

    public void addLike(int position) {

        int currentLikes = comments.get(position).getLikesNumber();
        currentLikes ++;
        Comment comment = new Comment();
        comment.setContent(comments.get(position).getContent());
        comment.setMemberName(comments.get(position).getMemberName());
        comment.setTime(comments.get(position).getTime());
        comment.setLikesNumber(currentLikes);


        commentReference = FirebaseDatabase.getInstance().getReference().child("Posts").child(postId).child("Comments").child(comments.get(position).getId());
        commentReference.setValue(comment);
        Toast.makeText(getApplicationContext(), "Like added successfully", Toast.LENGTH_SHORT).show();
    }

    public void DeleteComment(int position){

        //Cmompare UID SO U CAN'T DELETE UNTIL THEY HAVE THE SAME ID
        //DELETE
        //SHOW DELETE CONF.

        Comment comment = new Comment();
        comment.setContent(comments.get(position).getContent());
        comment.setMemberName(comments.get(position).getMemberName());
        comment.setTime(comments.get(position).getTime());
        comment.setLikesNumber(comments.get(position).getLikesNumber());
        myUID = comments.get(position).getId();


        // if (uId.equals(myUID)) {

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Posts").child(postId).child("Comments").child(comments.get(position).getId());
        // DatabaseReference commentReference1= FirebaseDatabase.getInstance().getReference().child("Posts").child(postId).child("Comments").child(comments.get(position).getContent());
        ref.removeValue();
        Toast.makeText(getApplicationContext(), "Comment has been deleted successfully", Toast.LENGTH_SHORT).show();

        // ref.child("comments").child(comments.get(position).getContent()).removeValue();
        //    else {
        //  Toast.makeText(getApplicationContext(), "You can't delete this comment", Toast.LENGTH_SHORT).show();
        //     ref.removeValue();

    }

    public class SendNotificationRequest extends AsyncTask<Void, Void, String> {

        protected void onPreExecute() {}

        protected String doInBackground(Void... arg0) {

            try {

                URL url = new URL("https://fcm.googleapis.com/fcm/send");

                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(15000 /* milliseconds */);
                conn.setConnectTimeout(15000 /* milliseconds */);
                conn.setRequestMethod("POST");
                conn.setDoInput(true);
                conn.setDoOutput(true);
                conn.setUseCaches(false);

                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Authorization", "key=AAAAi6stanY:APA91bEA2qBDU6VToEP4UnQCwca3-AE2xTW2OzqeBWCBBejdCTulsExSAZsUoMdtMTeSlX5PQVVSXKhkJTO3v4vzCAbguSlEQul2UaSwRHOXG4gU3F9l4rxkVyoHfq-J4WQ7sxiTHlsS");


                //region build json body
                JSONObject rootJSON = new JSONObject();

                JSONObject notificationJSON = new JSONObject();
                notificationJSON.put("body", SessionClass.MemberName + " commented on your Post");

                rootJSON.put("notification", notificationJSON);

                rootJSON.put("to", postMemberDeviceToken);
                //endregion

                String str =  rootJSON.toString();

                byte[] outputInBytes = str.getBytes("UTF-8");
                OutputStream os = conn.getOutputStream();
                os.write( outputInBytes );
                os.close();

                int responseCode = conn.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {

                    // Getting Response
                    BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    StringBuffer sb = new StringBuffer("");
                    String line = "";

                    while ((line = in.readLine()) != null) {

                        sb.append(line);
                        break;
                    }

                    in.close();
                    return sb.toString();

                } else {
                    return null;
                }


            } catch (Exception e) {
                return null;
            }

        }

        @Override
        protected void onPostExecute(String result) {

            if (result == null) {
                Toast.makeText(CommentsActivity.this, "Error in Sending Notification", Toast.LENGTH_SHORT).show();
                return;
            }
        }
    }
}
