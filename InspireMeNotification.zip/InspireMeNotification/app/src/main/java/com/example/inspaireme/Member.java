package com.example.inspaireme;


public class Member {

    private String id;
    private String Name ;
    private String Img;
    private String deviceToken;


    public Member() {


    }
    public String getName(){

        return this.Name;
    }

    public void setName(String name){
        this.Name = name ;

    }

    public void setImg(String img) {
        Img = img;
    }

    public String getImg() {
        return Img;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDeviceToken() {
        return deviceToken;
    }

    public void setDeviceToken(String deviceToken) {
        this.deviceToken = deviceToken;
    }
}
