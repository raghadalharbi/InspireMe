package com.example.inspaireme;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class PostActivity extends AppCompatActivity {


    //region views variables
    EditText etTitle;
    Spinner sCategory;
    ImageView ivPost;
    Button btnSelectImage;
    Button btnSendPost;
    //endregion

    //region other variables
    StorageReference storage;

    DatabaseReference postReference;

    static final int GALLERY_INTENT = 2;

    String imageUrl = "";

    String uId = "";

    ImageView ivGoBack2;

    List<String> categories;

    ProgressDialog progressDialog;
    //endregion

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post);


        //region views
        etTitle =  findViewById(R.id.et_title);
        sCategory = findViewById(R.id.s_category);

        categories = new ArrayList<>();
        categories.add("Choose Category");
        categories.add("BedRoom");
        categories.add("BathRoom");
        categories.add("LivingRoom");
        categories.add("Kitchen");
        categories.add("OutDoor");
        categories.add("DiningRoom");
        categories.add("Others");


        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, categories);

        // Drop down layout style - list view with radio button
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // attaching data adapter to spinner
        sCategory.setAdapter(dataAdapter);


        ivPost = findViewById(R.id.iv_post_image);

        btnSelectImage = findViewById(R.id.btn_select_image);
        btnSelectImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(Intent.ACTION_PICK);
                intent.setType("image/*");
                startActivityForResult(intent, GALLERY_INTENT);
            }
        });

        btnSendPost = findViewById(R.id.btn_send_post);
        btnSendPost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                send();

            }
        });
        //endregion

        //region other

        uId = getIntent().getStringExtra("UID");

        storage = FirebaseStorage.getInstance().getReference();

        progressDialog = new ProgressDialog(this);
        //endregion



        ivGoBack2 = findViewById(R.id.go_back);
        ivGoBack2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(PostActivity.this, Main.class);
                startActivity(i);

            }
        });

    }

    private void send () {

        //region validate
        if (etTitle.getText().toString().trim().equals("")){

            Toast.makeText(PostActivity.this, "You must enter a caption", Toast.LENGTH_SHORT).show();
            return;
        }

        if (sCategory.getSelectedItemPosition() == 0){

            Toast.makeText(PostActivity.this, "You must choose a category", Toast.LENGTH_SHORT).show();
            return;
        }

        if (imageUrl.trim().equals("")){

            Toast.makeText(PostActivity.this, "You must select a picture", Toast.LENGTH_SHORT).show();
            return;
        }
        //endregion


        MyPost myPost = new MyPost();
        myPost.setMemberID(uId);
        myPost.setMemberName(SessionClass.MemberName);
        myPost.setMemberPhoto(SessionClass.MemberPhoto);
        myPost.setMemberDeviceToken(SessionClass.MemberDeviceToken);
        myPost.setPostTitle(etTitle.getText().toString());
        myPost.setCategory(categories.get(sCategory.getSelectedItemPosition()));
        myPost.setImageUrl(imageUrl);



        postReference = FirebaseDatabase.getInstance().getReference().child("Posts").push();
        postReference.setValue(myPost);
        Toast.makeText(getApplicationContext(), "Post sent successfully", Toast.LENGTH_SHORT).show();

        finish();

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


        if (requestCode == GALLERY_INTENT) {

            if (resultCode == RESULT_OK) {

                progressDialog.setMessage("Uploading .....");
                progressDialog.show();

                Timestamp timestamp = new Timestamp(System.currentTimeMillis());
                String imageName = timestamp.toString();

                Uri uri = data.getData();

                final StorageReference filepath = storage.child("photos-posts").child("Image-" + imageName);
                filepath.putFile(uri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {


                        filepath.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                            @Override
                            public void onSuccess(Uri uri) {


                                imageUrl = uri.toString();

                                Glide.with(PostActivity.this).load(imageUrl).into(ivPost);

                                Toast.makeText(PostActivity.this, "upload done", Toast.LENGTH_LONG).show();
                                progressDialog.dismiss();
                            }
                        });


                    }
                });

            }

        }

    }
}
