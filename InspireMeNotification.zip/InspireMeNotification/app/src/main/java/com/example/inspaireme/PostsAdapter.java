package com.example.inspaireme;


import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;


import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;

public class PostsAdapter extends BaseAdapter {

    private static ArrayList<MyPost> posts;
    public Context mContext;

    public PostsAdapter(Context context, ArrayList<MyPost> comingPosts) {
        posts = comingPosts;
        mContext = context;
    }

    public View getView(final int position, View convertView, ViewGroup parent) {


        LayoutInflater mInflater = (LayoutInflater) mContext.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
        convertView = mInflater.inflate(R.layout.list_item_post, null);

        TextView tvTitle = convertView.findViewById(R.id.tv_post_title);

        ImageView ivPost = convertView.findViewById(R.id.iv_post_image);

        ImageView ivBookmark = convertView.findViewById(R.id.iv_bookmark);
        ivBookmark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((PostsListActivity) mContext).addPostToFavourites(position);
            }
        });

        Glide.with(mContext).load(posts.get(position).getImageUrl()).into(ivPost);

        tvTitle.setText(posts.get(position).getPostTitle());

        TextView tvMemberName = convertView.findViewById(R.id.tv_member_name);
        ImageView ivMemberPhoto = convertView.findViewById(R.id.iv_member_photo);

        Glide.with(mContext).load(posts.get(position).getMemberPhoto())
                .apply(RequestOptions.circleCropTransform()).
                into(ivMemberPhoto);
        tvMemberName.setText(posts.get(position).getMemberName());


        return convertView;
    }

    //region other methods
    public int getCount() {
        return posts.size();
    }

    public Object getItem(int position) {
        return posts.get(position);
    }

    public long getItemId(int position) {
        return position;
    }
    //endregion

}