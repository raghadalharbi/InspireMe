package com.example.inspaireme;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import java.util.ArrayList;
import java.util.List;

public class viewCategory extends AppCompatActivity {


    LinearLayout layoutBathroom, layoutKitchen, layoutOutdoor, layoutLivingRoom, layoutDiningRoom, layoutBedroom,layoutOthers;


    ImageView ivpostImg , ivProfile ,ivCategory;

    List<String> categories;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_category);


        categories = new ArrayList<>();
        categories.add("BedRoom");
        categories.add("BathRoom");
        categories.add("LivingRoom");
        categories.add("Kitchen");
        categories.add("OutDoor");
        categories.add("DiningRoom");
        categories.add("Others");


        layoutBathroom = findViewById(R.id.layout_bathroom);
        layoutBathroom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(viewCategory.this, PostsListActivity.class);
                i.putExtra("Category", categories.get(1));
                startActivity(i);

            }
        });

        layoutKitchen = findViewById(R.id.layout_kitchen);
        layoutKitchen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(viewCategory.this, PostsListActivity.class);
                i.putExtra("Category", categories.get(3));
                startActivity(i);

            }
        });

        layoutOutdoor = findViewById(R.id.layout_outdoor);
        layoutOutdoor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(viewCategory.this, PostsListActivity.class);
                i.putExtra("Category", categories.get(4));
                startActivity(i);

            }
        });

        layoutLivingRoom = findViewById(R.id.layout_living_room);
        layoutLivingRoom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(viewCategory.this, PostsListActivity.class);
                i.putExtra("Category", categories.get(2));
                startActivity(i);

            }
        });

        layoutDiningRoom = findViewById(R.id.layout_dining_room);
        layoutDiningRoom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(viewCategory.this, PostsListActivity.class);
                i.putExtra("Category", categories.get(5));
                startActivity(i);

            }
        });
        layoutBedroom = findViewById(R.id.layout_Bedroom);
        layoutBedroom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(viewCategory.this, PostsListActivity.class);
                i.putExtra("Category", categories.get(0));
                startActivity(i);

            }
        });

        layoutOthers = findViewById(R.id.layout_Others);
        layoutOthers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(viewCategory.this, PostsListActivity.class);
                i.putExtra("Category", categories.get(6));
                startActivity(i);

            }
        });


        ivpostImg = findViewById(R.id.iv_postImg);
        ivpostImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(viewCategory.this, PostActivity.class);
                startActivity(i);

            }
        });



        ivProfile = findViewById(R.id.imageView10);
        ivProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(viewCategory.this, Main.class);
                startActivity(i);

            }
        });

        ivCategory = findViewById(R.id.iv_category);
        ivCategory.setBackgroundResource(R.drawable.bb);
        ivCategory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent i = new Intent(viewCategory.this, viewCategory.class);
                startActivity(i);

            }
        });






    }


}
