package com.example.inspaireme;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.io.File;
import java.io.IOException;

public class Main extends AppCompatActivity {
    Button SIGNOUT;
    TextView tv;
    ImageView img;



    String uId = "";


    StorageReference storage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        uId = getIntent().getStringExtra("UID");

        tv = (TextView) findViewById(R.id.textView);

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference().child("Member").child(uId);
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String name = dataSnapshot.child("name").getValue().toString();
                String imgUrl = dataSnapshot.child("img").getValue().toString();
                tv.setText(name);
                Picasso.get().load(imgUrl).into(img);
            };

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        img = findViewById(R.id.imageView7);

        storage = FirebaseStorage.getInstance().getReference();

       /* SIGNOUT = (Button) findViewById(R.id.signout5);
        SIGNOUT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                finish();
                startActivity(new Intent(getApplicationContext(), MainActivity.class));
            }
        });*/


        SIGNOUT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                AlertDialog.Builder alertDialog = new AlertDialog.Builder(Main.this);

                alertDialog.setMessage("Are you sure you want to logout?")

                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                                Intent intent = new Intent(Main.this, Login.class);

                                startActivity(intent);

                                finish();

                            }
                        }).setNegativeButton("Cancel", null);

                AlertDialog alert = alertDialog.create();

                alert.show();

            }


        });
    }



}
