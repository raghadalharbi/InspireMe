package com.example.inspaireme;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;


public class Test extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);


        ImageView imageView = findViewById(R.id.imageView);

    Picasso.get().load("https://firebasestorage.googleapis.com/v0/b/inspireme-d384c.appspot.com/o/photos%2F18910623?alt=media&token=10e26410-6770-45d4-a6a7-825b9b4b6385").into(imageView);


    }
}
